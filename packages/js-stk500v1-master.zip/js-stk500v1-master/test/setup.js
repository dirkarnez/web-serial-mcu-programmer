require('mocha');
global.Should = require('should');
